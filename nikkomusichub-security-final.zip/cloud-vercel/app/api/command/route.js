import { NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { getStore, isSupabaseConfigured } from '@/lib/db';
import { publishCommand, listCommands } from '@/lib/mqtt';
import { evaluateStoreStatus } from '@/lib/alertRules';

const VALID_COMMANDS = new Set(listCommands().map((c) => c.key));

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  if (!isSupabaseConfigured()) {
    return NextResponse.json({ error: 'Supabase is required for remote commands' }, { status: 503 });
  }
  return NextResponse.json({ commands: listCommands() });
}

export async function POST(request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const data = await request.json();
  if (!VALID_COMMANDS.has(data.commandKey)) {
    return NextResponse.json({ error: 'Invalid commandKey' }, { status: 400 });
  }

  const store = await getStore(data.storeId);
  if (!store) return NextResponse.json({ error: 'Store not found' }, { status: 404 });

  const requestedTimeout = Number(data.timeout);
  let timeout = 30000;
  if (Number.isFinite(requestedTimeout)) {
    timeout = Math.min(Math.max(requestedTimeout, 5000), 180000);
  }

  const result = await publishCommand({
    broker: store.mqttBroker,
    port: store.mqttPort || (store.mqttTls === true ? 8883 : 1883),
    username: store.mqttUsername,
    password: store.mqttPassword,
    tls: store.mqttTls === true,
    tlsVerify: store.tlsVerify === true,
    storeId: store.storeId,
    commandKey: data.commandKey,
    timeout,
  });

  // Evaluate alert rules on status checks in the background.
  if (data.commandKey && data.commandKey.startsWith('status_')) {
    evaluateStoreStatus(store, result).catch(() => {});
  }

  return NextResponse.json(result);
}
