"""NikkoMusicHub FastAPI application."""
import os
from contextlib import asynccontextmanager

# Import first so missing/invalid env vars fail loudly on startup.
from app.core.config_validator import settings as validated_settings

from fastapi import FastAPI, Request
from fastapi.responses import RedirectResponse
from fastapi.staticfiles import StaticFiles
from starlette.middleware.gzip import GZipMiddleware

from app.config import BASE_DIR, DATA_DIR, LOGS_DIR, MUSIC_DIR, SCRIPTS_DIR
from app.db import init_db
from app.routes import auth, backup, dashboard, health, logs, network, player, self_test, settings, setup, system, version, webdav
from app.routes.auth import init_default_user
from app.routes.dashboard import bump_dashboard_version
from app.services.system import ensure_local_music_fallback
from app.db import set_dashboard_bump_callback


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup
    for d in (BASE_DIR, MUSIC_DIR, LOGS_DIR, SCRIPTS_DIR, DATA_DIR):
        d.mkdir(parents=True, exist_ok=True)
    init_db()
    init_default_user()
    set_dashboard_bump_callback(bump_dashboard_version)
    ensure_local_music_fallback()
    yield
    # Shutdown


app = FastAPI(title="NikkoMusicHub", lifespan=lifespan)
app.add_middleware(GZipMiddleware, minimum_size=500)
app.mount("/static", StaticFiles(directory="app/static"), name="static")


@app.middleware("http")
async def no_cache_headers(request: Request, call_next):
    """Force browsers and proxies to never cache any response."""
    response = await call_next(request)
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    response.headers["Pragma"] = "no-cache"
    response.headers["Expires"] = "0"
    return response

app.include_router(auth.router)
app.include_router(dashboard.router)
app.include_router(health.router)
app.include_router(setup.router)
app.include_router(webdav.router)
app.include_router(player.router)
app.include_router(system.router)
app.include_router(logs.router)
app.include_router(settings.router)
app.include_router(network.router)
app.include_router(version.router)
app.include_router(backup.router)
app.include_router(self_test.router)


@app.exception_handler(401)
async def unauthorized_handler(request: Request, exc):
    return RedirectResponse(url="/login", status_code=303)


if __name__ == "__main__":
    import uvicorn

    port = int(os.environ.get("NIKKO_PORT", "8080"))
    uvicorn.run("app.main:app", host="0.0.0.0", port=port, reload=False)
